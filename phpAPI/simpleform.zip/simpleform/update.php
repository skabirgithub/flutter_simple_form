<?php
header('Content-Type: application/json');
include "../simpleform/db.php";


$name = (String) $_POST['Name'];
$nic =  $_POST['Nic'];
$ime =  $_POST['Ime'];
$device_model =  $_POST['Device_Model'];
$mobile_no =  $_POST['Mobile_no'];
$reason =  $_POST['Reason'];
$address = $_POST['Address'];
$id = $_POST['id'];

// $stmt = $db->prepare("UPDATE student SET name = ?, age = ? WHERE id = ?");
$stmt = $db->prepare("UPDATE customer SET Name = ?, Nic = ?, Ime = ?, Device_Model = ?, Mobile_no = ?, Reason = ?, Address = ? WHERE id = ?");
$result =  $stmt->execute([$name, $nic, $ime, $device_model, $mobile_no, $reason, $address, $id]);

echo json_encode([
'success' => $result
]);